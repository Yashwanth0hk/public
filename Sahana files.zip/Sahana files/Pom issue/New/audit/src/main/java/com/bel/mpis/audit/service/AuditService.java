package com.bel.mpis.audit.service;

import java.util.List;

import com.bel.mpis.audit.dto.request.AuditSaveRequest;
import com.bel.mpis.audit.dto.response.AuditLogResponse;
import com.bel.mpis.audit.dto.response.SingleResponse;

import jakarta.servlet.http.HttpServletRequest;

public interface AuditService {


	public List<AuditLogResponse> getAllAuditLogs();

	public SingleResponse<?> saveAudit(AuditSaveRequest request, HttpServletRequest suRequest);

}
