package com.bel.mpis.audit.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuditSaveRequest {
    private String username;
    private String description;
    private String ipAddress;
 
}
