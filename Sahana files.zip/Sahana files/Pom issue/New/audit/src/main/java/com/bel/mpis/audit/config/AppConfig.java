package com.bel.mpis.audit.config;

import java.io.File;
import java.util.Properties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
//import org.springframework.web.reactive.function.client.WebClient;
//import com.google.code.kaptcha.impl.DefaultKaptcha;
//import com.google.code.kaptcha.util.Config;
//import io.netty.handler.ssl.SslContext;
//import io.netty.handler.ssl.SslContextBuilder;
//import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import jakarta.annotation.PostConstruct;
//import reactor.netty.http.client.HttpClient;

@Configuration
public class AppConfig {
//	@Bean
//	WebClient insecureWebClient() {
//
//		try {
//			SslContext sslContext = SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE)
//					.build();
//			HttpClient httpClient = HttpClient.create().secure(sslspec -> sslspec.sslContext(sslContext));
//			return WebClient.builder().clientConnector(new ReactorClientHttpConnector(httpClient))
//					.defaultHeader("Content-Type", "application/json")
//					.build();
//		} catch (Exception e) {
//			throw new RuntimeException(" error on loading insecureWebClient");
//		}
//	}
//	
//	@Bean
//     DefaultKaptcha captchaProducer() {
//        DefaultKaptcha kaptcha = new DefaultKaptcha();
//        Properties props = new Properties();
//        props.put("kaptcha.border", "no");
//        props.put("kaptcha.textproducer.font.color", "black");
//        props.put("kaptcha.textproducer.char.space", "5");
//        props.put("kaptcha.image.width", "200");
//        props.put("kaptcha.image.height", "50");
//        props.put("kaptcha.textproducer.font.size", "40");
//        props.put("kaptcha.textproducer.char.length", "5");
//
//        Config config = new Config(props);
//        kaptcha.setConfig(config);
//        return kaptcha;
//    }
	
//	@PostConstruct
//	public void configureSSL() {
//		System.setProperty("javax.net.ssl.trustStore", new File("src/main/resources/mytruststore.p12").getAbsolutePath());
//		System.setProperty("javax.net.ssl.trustStorePassword", "belproj");
//	}
	@PostConstruct
	public void configureSSL() {
		System.setProperty("javax.net.ssl.trustStore", new File("src/main/resources/mytruststore.p12").getAbsolutePath());
		System.setProperty("javax.net.ssl.trustStorePassword", "belproj");
	}
}
