package com.bel.mpis.audit.enums;

import org.springframework.lang.Nullable;



public enum CustomStatus {

	SUCCESS(1, Series.SUCCESSFUL, "SUCCESS"),
	FAILURE(0, Series.CLIENT_ERROR, "FAILURE"),
	USER_DATA_NOT_FOUND(-1, Series.CLIENT_ERROR, "USER NOT FOUND")
;

	
	private static final CustomStatus[] VALUES;

	static {
		VALUES = values();
	}

 
	private final int value;

	private final Series series;

	private final String message;

	CustomStatus(int value, Series series, String reasonPhrase) {
		this.value = value;
		this.series = series;
		this.message = reasonPhrase;
	}
	
	public int value() {
		return this.value;
	}
	
	

	public Series series() {
		return this.series;
	}


	public String getMessage() {
		return this.message;
	}


	public boolean isInformational() {
		return (series() == Series.INFORMATIONAL);
	}


	public boolean isSuccessful() {
		return (series() == Series.SUCCESSFUL);
	}

	
	public boolean isRedirection() {
		return (series() == Series.REDIRECTION);
	}

	
	public boolean isClientError() {
		return (series() == Series.CLIENT_ERROR);
	}

	public boolean isServerError() {
		return (series() == Series.SERVER_ERROR);
	}


	public boolean isError() {
		return (isClientError() || isServerError());
	}

	@Override
	public String toString() {
		return this.value + " " + name();
	}


	public static CustomStatus valueOf(int statusCode) {
		CustomStatus status = resolve(statusCode);
		if (status == null) {
			throw new IllegalArgumentException("No matching constant for [" + statusCode + "]");
		}
		return status;
	}

	
	@Nullable
	public static CustomStatus resolve(int statusCode) {
		// Use cached VALUES instead of values() to prevent array allocation.
		for (CustomStatus status : VALUES) {
			if (status.value == statusCode) {
				return status;
			}
		}
		return null;
	}

	public enum Series {

		INFORMATIONAL(1),
		SUCCESSFUL(2),
		REDIRECTION(3),
		CLIENT_ERROR(4),
		SERVER_ERROR(5);

		private final int value;

		Series(int value) {
			this.value = value;
		}

		
		public int value() {
			return this.value;
		}

		@Deprecated
		public static Series valueOf(CustomStatus status) {
			return status.series;
		}

		public static Series valueOf(int statusCode) {
			Series series = resolve(statusCode);
			if (series == null) {
				throw new IllegalArgumentException("No matching constant for [" + statusCode + "]");
			}
			return series;
		}

		
		@Nullable
		public static Series resolve(int statusCode) {
			int seriesCode = statusCode / 100;
			for (Series series : values()) {
				if (series.value == seriesCode) {
					return series;
				}
			}
			return null;
		}
	}

}
