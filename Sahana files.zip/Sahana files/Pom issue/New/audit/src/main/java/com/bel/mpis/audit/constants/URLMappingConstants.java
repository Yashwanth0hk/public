package com.bel.mpis.audit.constants;

public class URLMappingConstants {

	// Auth Controller
	public static final String AUDIT_CONTROLLER = "/api/audit";

	// Audit
	public static final String TEST = "/test";
	public static final String SAVE_AUDIT_LOG = "/saveAuditLog";
	public static final String GET_ALL_AUDIT_LOG = "/getAllAuditLog";
}
