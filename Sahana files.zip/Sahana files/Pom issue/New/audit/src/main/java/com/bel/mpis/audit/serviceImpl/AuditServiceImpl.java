package com.bel.mpis.audit.serviceImpl;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bel.mpis.audit.dto.request.AuditSaveRequest;
import com.bel.mpis.audit.dto.response.AuditLogResponse;
import com.bel.mpis.audit.dto.response.SingleResponse;
import com.bel.mpis.audit.entity.AuditLog;
import com.bel.mpis.audit.enums.CustomStatus;
import com.bel.mpis.audit.repository.AuditRepository;
import com.bel.mpis.audit.service.AuditService;
import com.bel.mpis.audit.utils.CommonFunction;
import com.bel.mpis.utility.enums.EventType;
import com.bel.mpis.utility.enums.Priority;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AuditServiceImpl implements AuditService {

	@Autowired
	private AuditRepository auditLogRepository;

	private final CommonFunction commonFunction;

	@Override
	public List<AuditLogResponse> getAllAuditLogs() {

		List<AuditLog> auditList = auditLogRepository.getAllAuditLog();

		List<AuditLogResponse> listResponse = auditList.stream().map(auditLog -> {
			AuditLogResponse auditLogResponse = new AuditLogResponse();
			auditLogResponse.setCreatedOn(auditLog.getCreatedOn());
			auditLogResponse.setAuditUserName(auditLog.getUsername());
			auditLogResponse.setDescription(auditLog.getDescription());
			auditLogResponse.setIpAddress(auditLog.getIpAddress());
			auditLogResponse.setEventType(auditLog.getEventType());
			auditLogResponse.setLevelType(auditLog.getPriority());
			return auditLogResponse;
			
		}).collect(Collectors.toList());
		return listResponse;

	}

	@Override
	@Transactional
	public SingleResponse<?> saveAudit(AuditSaveRequest request, HttpServletRequest suRequest) {
		try {
			AuditLog auditLog = new AuditLog();
						String ipAddress = commonFunction.getIp(suRequest);
			auditLog.setUsername(request.getUsername());
			auditLog.setDescription(request.getDescription());
			auditLog.setIpAddress(ipAddress);
			auditLog.setPriority(Priority.HIGH.name());
			auditLog.setEventType(EventType.LOGIN.name());
			
			auditLogRepository.save(auditLog);

			return new SingleResponse<>(Collections.singletonMap("message", "Audit Logged Successfully"),
					"Stored In Database", CustomStatus.SUCCESS);

		} catch (Exception e) {
			// Log the error for debugging purposes (important!)
			System.err.println("Error saving audit log: " + e.getMessage()); // or use a proper logger
			return new SingleResponse<>(Collections.singletonMap("message", "Failed to log audit. Please check logs."),
					CustomStatus.FAILURE);
		}
	}

}
