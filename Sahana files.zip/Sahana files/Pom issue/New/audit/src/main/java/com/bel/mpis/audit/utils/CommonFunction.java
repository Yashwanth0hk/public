package com.bel.mpis.audit.utils;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.bel.mpis.audit.exception.CustomException;

import jakarta.servlet.http.HttpServletRequest;

@Component
public class CommonFunction {

	@Value("${jwt.expiration.refresh:900000}")
	private long refreshTokenExpiration;

	private static final List<String> PUBLIC_URLS = List.of("/api/auth/**", "/api/non-auth/**");

	public List<String> publicUrls() {
		return PUBLIC_URLS;
	}

	public long refreshTokenExpireTome() {
		return refreshTokenExpiration;
	}

	public String getIp(HttpServletRequest suRequest) {
		System.out.println("suRequest.getRemoteAddr()--" + suRequest.getRemoteAddr());
		if (suRequest.getHeader("X-Forwarded-For") != null) {
			String[] ips = suRequest.getHeader("X-Forwarded-For").split(",");
			if (ips.length > 0)
				return ips[0].trim(); // Take the first IP address
		} else {
			String ips = suRequest.getRemoteAddr();
			if (ips != null)
				return ips;
		}
		throw new CustomException("Ip Data Not Found Audit ", HttpStatus.FORBIDDEN);
	}


}
