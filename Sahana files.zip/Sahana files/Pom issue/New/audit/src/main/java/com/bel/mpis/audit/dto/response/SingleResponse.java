package com.bel.mpis.audit.dto.response;

import com.bel.mpis.audit.enums.CustomStatus;

import lombok.Data;

@Data
public class SingleResponse<T> {

	private StatusCode response;
	private String message;
	private T data;

	

	public SingleResponse(T data, CustomStatus status) {
		this.response = new StatusCode(status);
		this.data = data;
	}

	public SingleResponse(T data, String message, CustomStatus status) {
		this.response = new StatusCode(status);
		this.message = message;
		this.data = data;
	}

	
	
	
}
