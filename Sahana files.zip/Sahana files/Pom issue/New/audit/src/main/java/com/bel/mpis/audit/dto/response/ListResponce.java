package com.bel.mpis.audit.dto.response;

import java.util.List;

import com.bel.mpis.audit.enums.CustomStatus;

import lombok.Data;

@Data
public class ListResponce<T> {
	
	private StatusCode response;
	private List<T> data;
	
	
	public ListResponce( List<T> data,CustomStatus status) {
		this.response = new StatusCode(status);
		this.data = data;
	}
	
}
