package com.bel.mpis.audit.exception;

import org.springframework.http.HttpStatus;

import lombok.Getter;

@Getter
public class CustomException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final int errorCode;
	private final HttpStatus httpStatus;
	private final String message;

	public CustomException(String message, int errorCode, HttpStatus httpStatus) {
		this.errorCode = errorCode;
		this.httpStatus = httpStatus;
		this.message = message;
	}

	public CustomException(String message, HttpStatus httpStatus) {
		this.message = message;
		this.errorCode = httpStatus.value();
		this.httpStatus = httpStatus;
	}

	public CustomException(String message) {
		this.message = message;
		this.errorCode = 500; // Default Error Code
		this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
	}
	
//	public CustomException(String message, int errorCode) {
//		this.errorCode = errorCode;
//		this.httpStatus = httpStatus.;
//		this.message = message;
//	}

}