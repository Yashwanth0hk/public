package com.bel.mpis.audit.dto.response;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Data
public class AuditLogResponse {
	
	private LocalDateTime createdOn;
	private String auditUserName;
	private String description;
	 private String ipAddress;
	private String eventType;
	private String levelType;
}
