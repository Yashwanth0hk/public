/********************************************************************
   Project  	: Signal Command And Control Planner
   File Name  	: AuditDTO.java
   Author	 	: Sathi Das
   Purpose		: This is the DTO class of Audit.
   Created Date : January 27, 2025	
 ********************************************************************/

package com.bel.mpis.audit.dto.request;

import java.util.Date;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@ToString
public class AuditDTO {
	private Long id;
	private Date time;
	private String audittype;
	private String username;
	private String description;
	private String source;
}