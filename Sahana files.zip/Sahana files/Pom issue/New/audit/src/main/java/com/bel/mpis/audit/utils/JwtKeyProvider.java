package com.bel.mpis.audit.utils;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.security.KeyFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import org.springframework.core.io.Resource;

@Component
public class JwtKeyProvider {

	// Inject the private key resource (file path) from application.properties
	@Value("${jwt.private-key}")
	private Resource privateKeyResource;

	// Inject the public key resource (file path) from application.properties
	@Value("${jwt.public-key}")
	private Resource publicKeyResource;

	// Inject the private key resource for scheduler role (file path) from
	// application.properties
	@Value("${jwt.private-key-scheduler-role}")
	private Resource privateKeyResourceForSchedulerRole;

	// Inject the public key resource for scheduler role (file path) from
	// application.properties
	@Value("${jwt.public-key-scheduler-role}")
	private Resource publicKeyResourceForSchedulerRole;

	// Variables to hold the loaded keys
	@Getter
	private PrivateKey privateKey;
	
	@Getter
	private PublicKey publicKey;

	// Variables to hold the loaded keys For SchedulerRole
	@Getter
	private PrivateKey privateKeyForSchedulerRole;

	@Getter
	private PublicKey publicKeyForSchedulerRole;

	/**
	 * This method is called after the bean is fully initialized. It loads the
	 * private and public keys from the files specified in the properties file. The
	 * keys are Base64-decoded, stripped of headers/footers, and parsed into
	 * PrivateKey and PublicKey objects.
	 */
	@PostConstruct
	public void init() throws Exception {
		this.privateKey = getPrivateKey(privateKeyResource.getFile().toPath());
		this.publicKey = getPublicKey(publicKeyResource.getFile().toPath());
		this.privateKeyForSchedulerRole = getPrivateKey(privateKeyResourceForSchedulerRole.getFile().toPath());
		this.publicKeyForSchedulerRole = getPublicKey(publicKeyResourceForSchedulerRole.getFile().toPath());
	}

	private PrivateKey getPrivateKey(Path resourcePath) throws Exception {
		// Load and process the private key
		String privateKeyPem = Files.readString(resourcePath) // Read the private key file
				.replace("-----BEGIN PRIVATE KEY-----", "") // Remove the PEM header
				.replace("-----END PRIVATE KEY-----", "") // Remove the PEM footer
				.replaceAll("\\s+", ""); // Remove any spaces or line breaks

		// Decode the Base64-encoded private key content
		byte[] privateKeyBytes = Base64.getDecoder().decode(privateKeyPem);

		// Create a KeyFactory for RSA and generate the PrivateKey object
		PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(privateKeyBytes); // KeySpec for private key format
		return KeyFactory.getInstance("RSA").generatePrivate(spec);
	}

	private PublicKey getPublicKey(Path resourcePath) throws Exception {
		// Load and process the public key
		String publicKeyPem = Files.readString(publicKeyResource.getFile().toPath()) // Read the public key file
				.replace("-----BEGIN PUBLIC KEY-----", "") // Remove the PEM header
				.replace("-----END PUBLIC KEY-----", "") // Remove the PEM footer
				.replaceAll("\\s+", ""); // Remove any spaces or line breaks

		// Decode the Base64-encoded public key content
		byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyPem);

		// Create a KeyFactory for RSA and generate the PublicKey object
		X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(publicKeyBytes); // KeySpec for public key format
		return KeyFactory.getInstance("RSA").generatePublic(pubSpec); // Generate PublicKey

	}
}