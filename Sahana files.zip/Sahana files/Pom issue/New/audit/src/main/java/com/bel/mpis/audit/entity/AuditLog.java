/********************************************************************
Project  		: NMS-CORE
System			: Audit    
File Name  		: Audit.java
Author	 		: Sathi Das
Purpose			: This is an entity class to hold the database entries 
				  of am_audit_log table
Created Date 	: Aug 04, 2023	
********************************************************************/

package com.bel.mpis.audit.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "am_audit_log", schema = "rnms_schema_audit")
@Getter
@Setter
@NoArgsConstructor
@ToString
public class AuditLog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@Column(nullable = false, updatable = false)
	@CreationTimestamp
	private LocalDateTime createdOn;

	@Column(name = "username", nullable = true, length = 150, columnDefinition = "character varying(150) default ''")
	private String username;

	@Column(name = "description", nullable = false, length = 255, columnDefinition = "character varying(255) default ''")
	private String description;

	@Column(nullable = false)
	private String eventType;

	@Column(name = "ipAddress", nullable = false, length = 150, columnDefinition = "character varying(150) default ''")
	private String ipAddress;

	@Column(nullable = false)
	private String priority;
	

}
