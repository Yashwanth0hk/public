package com.bel.mpis.audit.dto.response;

import com.bel.mpis.audit.enums.CustomStatus;

public class StatusCode {
	
	public StatusCode(CustomStatus code) {
		this.code = code;
	}

	CustomStatus code;

	public int getCode() {
		return code.value();
	}

	public void setCode(CustomStatus code) {
		this.code = code;
	}

}
