package com.bel.mpis.audit.enums;

public enum ActiveEnum {
      Y,
      N
}
