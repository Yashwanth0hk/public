package com.bel.mpis.audit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bel.mpis.audit.constants.URLMappingConstants;
import com.bel.mpis.audit.dto.request.AuditSaveRequest;
import com.bel.mpis.audit.dto.response.AuditLogResponse;
import com.bel.mpis.audit.dto.response.ListResponce;
import com.bel.mpis.audit.dto.response.SingleResponse;
import com.bel.mpis.audit.enums.CustomStatus;
import com.bel.mpis.audit.service.AuditService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping(URLMappingConstants.AUDIT_CONTROLLER)
@AllArgsConstructor
@SuppressWarnings({ "rawtypes", "unchecked" })
public class AuditController {

	@Autowired
	private AuditService auditService;

	@GetMapping(URLMappingConstants.TEST)
	public String CHECK() {
			return "Hello";
	}

	@PostMapping(URLMappingConstants.SAVE_AUDIT_LOG)
	public SingleResponse<?> saveAuditData(@Valid @RequestBody AuditSaveRequest request,
			HttpServletRequest suRequest) {
		return auditService.saveAudit(request, suRequest);
	}

	@GetMapping(URLMappingConstants.GET_ALL_AUDIT_LOG)
	public ListResponce<?> getAllAuditLog() {
		List<AuditLogResponse> auditLogs = auditService.getAllAuditLogs();
		return new ListResponce(auditLogs, CustomStatus.SUCCESS);
	}

}
