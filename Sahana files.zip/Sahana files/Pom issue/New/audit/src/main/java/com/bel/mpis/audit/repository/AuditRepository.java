package com.bel.mpis.audit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.bel.mpis.audit.entity.AuditLog;

@Repository
public interface AuditRepository extends JpaRepository<AuditLog, Long> {

	@Query("Select a from AuditLog a")
	public List<AuditLog> getAllAuditLog();

}
