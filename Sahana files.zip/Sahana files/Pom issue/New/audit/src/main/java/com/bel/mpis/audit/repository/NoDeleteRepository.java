package com.bel.mpis.audit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface NoDeleteRepository<T, ID> extends JpaRepository<T, ID> {

	 /**
     * @deprecated Use soft delete (e.g., active flag) instead.
     */
    @Deprecated
    @Override
    default void delete(T entity) {
        throw new UnsupportedOperationException("Delete is disabled. Use soft delete instead.");
    }

    /**
     * @deprecated Use soft delete (e.g., active flag) instead.
     */
    @Deprecated
    @Override
    default void deleteById(ID id) {
        throw new UnsupportedOperationException("Delete is disabled. Use soft delete instead.");
    }

    /**
     * @deprecated Use soft delete (e.g., active flag) instead.
     */
    @Deprecated
    @Override
    default void deleteAll() {
        throw new UnsupportedOperationException("Delete is disabled. Use soft delete instead.");
    }

    /**
     * @deprecated Use soft delete (e.g., active flag) instead.
     */
    @Deprecated
    @Override
    default void deleteAll(Iterable<? extends T> entities) {
        throw new UnsupportedOperationException("Delete is disabled. Use soft delete instead.");
    }

    /**
     * @deprecated Use soft delete (e.g., active flag) instead.
     */
    @Deprecated
    @Override
    default void deleteAllById(Iterable<? extends ID> ids) {
        throw new UnsupportedOperationException("Delete is disabled. Use soft delete instead.");
    }
}
