package com.bel.mpis.audit.exception;

import java.time.LocalDateTime;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;


@RestControllerAdvice
@SuppressWarnings("unused")
public class GlobalExceptionHandler {

	@ExceptionHandler(BadCredentialsException.class)
	public ResponseEntity<ErrorMessage> handleBadCredentials(BadCredentialsException ex, WebRequest request) {
		ErrorMessage error = new ErrorMessage(HttpStatus.UNAUTHORIZED.value(), LocalDateTime.now(), ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(UsernameNotFoundException.class)
	public ResponseEntity<ErrorMessage> handleUserNotFound(UsernameNotFoundException ex, WebRequest request) {
		ErrorMessage error = new ErrorMessage(HttpStatus.UNAUTHORIZED.value(), LocalDateTime.now(), "User not found",
				request.getDescription(false));
		return new ResponseEntity<>(error, HttpStatus.UNAUTHORIZED);
	}
	
	

	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<ErrorMessage> handleAccessDenied(AccessDeniedException ex, WebRequest request) {
		ErrorMessage error = new ErrorMessage(HttpStatus.FORBIDDEN.value(), LocalDateTime.now(), "Access denied",
				request.getDescription(false));
		return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
	}
//
//	@ExceptionHandler(Exception.class)
//	public ResponseEntity<ErrorMessage> handleAllExceptions(Exception ex, WebRequest request) {
//        String errorMessage = extractErrorMessage(ex);
//		ErrorMessage error = new ErrorMessage(HttpStatus.INTERNAL_SERVER_ERROR.value(), LocalDateTime.now(),
//				errorMessage, request.getDescription(false));
//		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
//	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorMessage> handleValidExceptions(MethodArgumentNotValidException ex, WebRequest request) {
		ErrorMessage error = new ErrorMessage(HttpStatus.INTERNAL_SERVER_ERROR.value(), LocalDateTime.now(),
				ex.getBindingResult().getFieldError().getDefaultMessage(), request.getDescription(false));
		return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ErrorMessage> handleCustomException(CustomException ex, WebRequest request) {
		ErrorMessage error = new ErrorMessage(ex.getHttpStatus().value(), LocalDateTime.now(), ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity<>(error,ex.getHttpStatus());
	}

	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<String> handleDbConstraintViolation(DataIntegrityViolationException ex) {
	    return ResponseEntity.status(HttpStatus.BAD_REQUEST)
	                         .body("Invalid data provided. Please check your input");
	}

	
	private String extractErrorMessage(Throwable ex) {
        if (ex.getMessage() != null && !ex.getMessage().isBlank()) {
            return ex.getMessage();
        } else if (ex.getCause() != null) {
            return extractErrorMessage(ex.getCause());  // recurse to root cause
        } else {
            return "Unexpected error occurred.";
        }
    }
}
