package com.bel.mpis.utility.enums;

public enum ActiveEnum {
      Y,
      N
}
