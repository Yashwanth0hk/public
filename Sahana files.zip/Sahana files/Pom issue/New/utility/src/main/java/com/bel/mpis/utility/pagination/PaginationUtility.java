/********************************************************************
   Project  	: Mumbai Police (MPIS)
   File Name  	: PaginationUtility.java
   Author	 	: Sathi 
   Purpose		: This is a class for utility of pagination 				  
   Created Date : Spe 04, 2025	
 ********************************************************************/
package com.bel.mpis.utility.pagination;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;

public class PaginationUtility {

	public static Sort.Direction getSortDirection(String direction) {
		if (direction.equals("desc")) {
			return Sort.Direction.DESC;
		} else if (direction.equals("asc")) {
			return Sort.Direction.ASC;
		}
		return Sort.Direction.ASC;
	}

	public static Sort.Direction getSortDirectionWithOrderName(String direction) {

		if (direction.equalsIgnoreCase("desc")) {
			return Sort.Direction.DESC;
		}

		if (direction.equalsIgnoreCase("asc")) {
			return Sort.Direction.ASC;
		}

		return Sort.Direction.DESC;
	}

	public static final String DEFAULT_PAGE_NO = "0";
	public static final String DEFAULT_PAGE_SIZE = "10";

	public static List<Order> setPageOrder(String sortOrder) {
		List<Order> orders = new ArrayList<Order>();
		if (sortOrder.contains(",")) {
			String[] sortItem = sortOrder.split(",");
			orders.add(new Order(PaginationUtility.getSortDirection(sortItem[1]), sortItem[0]));
		}
		return orders;
	}
	
	public static String setHqlOrder(String sortOrder) {
		String[] sortItems = sortOrder.split(",");
		if (sortItems.length == 2) {
			return sortItems[0] + " " + sortItems[1];
		}
		// Handle cases where sortOrder doesn't contain a comma or has more than 2 items
		return "";
	}

	public static Map<String, String> setHqlFilter(String key, String value) {
		Map<String, String> filter = new HashedMap<>();
		if (key != null && !key.isBlank() && value != null && !value.isBlank()) {
			List<String> keys = Arrays.asList(key.split(","));
			List<String> values = Arrays.asList(value.split(","));
			if (keys.size() == values.size()) {
				for (int i = 0; i < keys.size(); i++) {
					filter.put(keys.get(i), values.get(i));
				}
			}

		}
		return filter;
	}
}
