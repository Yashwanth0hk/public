package com.bel.mpis.utility.leave.enums;

public enum LeaveStatus {
	PENDING,
    RECOMMENDED,
    APPROVED,
    REJECTED,
    CANCELLED
}
