package com.bel.mpis.utility.enums;

public enum Priority {

	LOW, MEDIUM, HIGH

}
