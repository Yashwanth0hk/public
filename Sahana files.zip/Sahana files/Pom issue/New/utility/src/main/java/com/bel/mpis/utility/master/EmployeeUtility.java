/********************************************************************
   Project  	: Mumbai Police (MPIS)
   File Name  	: EmployeeUtility.java
   Author	 	: Sathi Das
   Purpose		: This is an utility class for employee details
    			  management  				  
   Created Date : Aug 19, 2025		
 ********************************************************************/

package com.bel.mpis.utility.master;

import java.util.List;

public  class EmployeeUtility {
	
	static List<String> officerRanks = List.of("ACP","DCP","ADDLCP","JTCP","CP");

	public static Boolean isOfficer(String rank) {		
		return officerRanks.contains(rank.toUpperCase());
		
	}
	
	
    public static List<String> getOfficerRanks() {
		return officerRanks;
	}


	
}
