package com.bel.mpis.utility.leave.enums;

public enum LeaveType {
    CASUAL_LEAVE,
    ANNUAL_LEAVE,
    SICK_LEAVE,
    MATERNITY_LEAVE,
    PATERNITY_LEAVE,
    EMERGENCY_LEAVE
}
