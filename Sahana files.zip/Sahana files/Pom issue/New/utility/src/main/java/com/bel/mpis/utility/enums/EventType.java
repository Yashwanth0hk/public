package com.bel.mpis.utility.enums;

public enum EventType {

	LOGIN, LOGOUT,LOGIN_FAILED,INVALID_CAPTCHA,CAPTCHA_DATA_NOT_FOUND
}
